import { Component } from '@angular/core';

@Component({
  selector: 'app-redes-sociais',
  templateUrl: './redes-sociais.component.html',
  styleUrls: ['./redes-sociais.component.css']
})
export class RedesSociaisComponent {

  constructor() { 
  }

  // Quaisquer métodos e lógica adicional podem ser adicionados aqui.

}
