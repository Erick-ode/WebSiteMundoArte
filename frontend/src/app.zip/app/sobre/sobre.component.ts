import { Component } from '@angular/core';

@Component({
  selector: 'app-sobre',
  templateUrl: './sobre.component.html',
  styleUrls: ['./sobre.component.css']
})
export class SobreComponent {

  constructor() { }

  // Quaisquer métodos e lógica adicional podem ser adicionados aqui.

}
