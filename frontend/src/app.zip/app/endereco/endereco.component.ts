import { Component } from '@angular/core';

@Component({
  selector: 'app-endereco',
  templateUrl: './endereco.component.html',
  styleUrls: ['./endereco.component.css']
})
export class EnderecoComponent {

  constructor() { }

  // Quaisquer métodos e lógica adicional podem ser adicionados aqui.

}
